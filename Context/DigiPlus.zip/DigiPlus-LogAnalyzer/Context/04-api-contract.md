# API Contract — Source of Truth

Both agents build against exactly this. If it needs to change, edit this file first,
then both sides update. Base URL: `/api`.

## Entities

```ts
type Severity = "info" | "low" | "medium" | "critical";

interface LogEntry {
  id: string;
  timestamp: string;       // ISO 8601
  source: string;          // IP address
  eventType: string;       // Request_Type
  severity: Severity;      // derived, see 02-dataset.md
  statusCode: number;
  userAgent: string;
  sessionId: string;
  location: string;
  flagged: boolean;
  createdAt: string;
}

interface Anomaly {
  id: string;
  logEntryId: string;
  score: number;            // 0-100
  reasonCodes: string[];    // e.g. ["RATE_BURST", "RARE_LOCATION"]
  reasonSummary: string;    // deterministic, human-readable, NOT AI-generated
  ruleVersion: string;
  createdAt: string;
}

interface Explanation {
  id: string;
  anomalyId: string;
  explanation: string;      // plain-English, AI-generated
  likelyRootCause: string;  // AI-generated
  recommendedNextStep: string; // AI-generated
  model: string;
  generatedAt: string;
}
```

## Endpoints

### `POST /api/logs/ingest`
Ingest a dataset (multipart file upload, CSV) or a JSON array of raw rows. Runs
validation + persistence + anomaly detection synchronously (dataset is small enough).

- **Response 200**
  ```json
  {
    "totalRows": 10000,
    "ingested": 9998,
    "rejected": 2,
    "rejectedReasons": [
      { "row": 4821, "reason": "missing timestamp" },
      { "row": 9102, "reason": "malformed status code" }
    ],
    "flagged": 47
  }
  ```
- **Response 422** — empty dataset / no parseable rows:
  ```json
  { "error": "EMPTY_DATASET", "message": "No valid rows found in the uploaded file." }
  ```

### `GET /api/logs`
List log entries, paginated.

Query params: `page` (default 1), `pageSize` (default 25, max 100), `flagged` (bool,
optional), `severity` (optional), `from`/`to` (ISO date, optional), `q` (search on
source/location, optional).

- **Response 200**
  ```json
  {
    "items": [ /* LogEntry[] */ ],
    "page": 1,
    "pageSize": 25,
    "total": 10000,
    "totalPages": 400
  }
  ```

### `GET /api/logs/:id`
Single `LogEntry`. **404** if not found.

### `GET /api/anomalies`
List flagged entries with their anomaly record, paginated.

Query params: `page`, `pageSize`, `minScore` (optional), `reasonCode` (optional).

- **Response 200**
  ```json
  {
    "items": [ { "logEntry": {}, "anomaly": {} } ],
    "page": 1, "pageSize": 25, "total": 47, "totalPages": 2
  }
  ```

### `GET /api/anomalies/:id`
Single anomaly + its `logEntry` + its `explanation` if one has already been generated
(`explanation: null` if not yet requested). **404** if not found.

### `POST /api/anomalies/:id/explain`
Generate (or regenerate, with `{ "force": true }` body) the AI explanation for this
anomaly. This is the on-demand trigger described in `03-architecture.md`.

- **Response 200** — the `Explanation` object.
- **Response 502** — AI provider call failed:
  ```json
  { "error": "AI_PROVIDER_ERROR", "message": "Explanation generation failed. Try again." }
  ```
  (Never fall back to templated fake text here — see `06-ai-explanation-design.md`.)

### `GET /api/stats/summary`
For a dashboard/timeline header.

- **Response 200**
  ```json
  {
    "totalLogs": 10000,
    "totalFlagged": 47,
    "bySeverity": { "critical": 12, "medium": 20, "low": 10, "info": 5 },
    "byReasonCode": { "RATE_BURST": 1, "RARE_LOCATION": 10, "ERROR_BURST": 8, "SESSION_ANOMALY": 3 },
    "timeRange": { "from": "2023-01-01T00:00:00Z", "to": "2023-01-07T22:39:00Z" }
  }
  ```

## Error shape (all endpoints)

```json
{ "error": "MACHINE_READABLE_CODE", "message": "Human-readable message" }
```

Standard HTTP status codes: `400` validation, `404` not found, `422` semantically empty
input, `500` unexpected, `502` upstream AI provider failure.
