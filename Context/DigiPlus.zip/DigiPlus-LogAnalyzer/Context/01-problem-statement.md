# Problem Statement (condensed)

**Assessment:** Smart Log Analyzer & Anomaly Detector — DigiPlus ACOE Technical Assessment
**Duration:** 3.5 hours
**Submission:** Source code + README (setup, AI config, approach, assumptions, limitations)
**AI coding assistants allowed** — but you must be able to explain every decision.

## The ask, in one paragraph

Build an app that ingests log data, persists it, flags unusual entries using an algorithm
you design yourself (not the AI), and uses AI purely to turn each flagged entry into a
plain-English explanation and a likely root cause / next step. Users should be able to
view and manage the logs (a list/timeline with flagged entries highlighted, plus a detail
view), and the app should handle basic validation issues (missing timestamps, malformed
entries, empty dataset).

## Hard requirements

- [ ] Load and persist log entries — minimum fields: **timestamp, event type, severity,
      source**.
- [ ] Flag unusual entries using **your own** algorithm/approach (any technique is fine —
      it must not be the AI model deciding what's anomalous).
- [ ] Persist each flagged entry with a **brief reason or score** explaining why it was
      flagged.
- [ ] Use **AI** to generate, per flagged entry: a plain-English explanation + a likely
      root cause or next step. Must be a real model call, not templated/hard-coded text
      dressed up as AI output.
- [ ] UI: list or timeline view with flagged entries visibly highlighted, plus a detail
      view per entry.
- [ ] Handle basic validation: missing timestamps, malformed entries, empty dataset —
      gracefully, not with a crash.
- [ ] Tech stack, architecture, and schema are **not prescribed** — make your own calls
      and be ready to justify them (see `03-architecture.md` for the calls this project
      made and why).

## Optional / brownie points

Original, well-justified additions beyond the basic requirements. See
`09-frontend-agent.md` and `08-backend-agent.md` Phase 4 for the enhancements this
project chose to attempt if time allows.

## Assessment rubric (what's actually being graded)

| Area | Focus |
|---|---|
| Functionality | Working, coherent end-to-end solution |
| AI | Appropriate use, reasoning, reliability |
| Engineering | Design, code quality, maintainability |
| Data | Persistence and sensible data handling |
| UX | Clarity and usability |
| Problem solving | Technical decisions, trade-offs, originality |

`10-acceptance-criteria.md` maps every build task back to one of these six rows so
there's an objective way to check "are we actually done" before submission.

## Sample data note

The PDF's inline example table is illustrative only — **not** the dataset to build
against. The real, larger dataset (`Resources/log-data.csv`, 10,000 rows) is what this
project actually targets; its real schema and characteristics are documented in
`02-dataset.md` and differ from the PDF's illustrative column names (e.g. no explicit
"severity" field exists — it's derived, see `02-dataset.md`).
