# Anomaly Detection Design (Backend Agent implements this exactly)

**This logic is deterministic and hand-written. The AI model never decides what counts
as anomalous** — that's a hard requirement from the problem statement. This file is the
spec; treat it as the algorithm to implement, not a suggestion.

## Approach: weighted multi-rule scoring engine

Each rule inspects the dataset (already persisted) and independently proposes a
sub-score + reason code for a given `LogEntry`. Scores combine into one `anomaly_score`
(0–100). An entry is flagged if the combined score crosses a threshold, or if any single
rule is configured as a hard-flag rule. This is intentionally a transparent, explainable
statistical approach (not an opaque ML model) — every flag can be justified in one
sentence, which both satisfies the rubric's "reasoning and reliability" row and gives the
AI explanation step real, concrete material to work with instead of guessing.

## Rules

### R1 — Rate/burst per source IP (`RATE_BURST`)
For each `IP_Address`, count requests in a rolling 10-minute window. Given the dataset's
overall rate (~1 request/minute across ~10,000 unique-ish IPs, i.e. almost every IP
should appear once), flag any IP whose count in a window exceeds a configurable
threshold — default **`RATE_BURST_THRESHOLD = 8`** requests / 10-minute window. This
directly catches the `15.6.62.53` × 49 case found in the real dataset (see
`02-dataset.md`).
Sub-score: `min(100, (count / threshold) * 60)`.

### R2 — Error-burst per source IP (`ERROR_BURST`)
For each `IP_Address` with ≥3 requests in a 10-minute window, compute the fraction that
are `4xx`/`5xx`. Flag if fraction ≥ **0.6**. Catches a source repeatedly hitting broken
or forbidden endpoints.
Sub-score: `fraction * 70`.

### R3 — Rarity of categorical field (`RARE_LOCATION`, `RARE_USER_AGENT`)
At startup/ingestion, compute frequency of each `Location` and `User_Agent` value across
the full dataset. Any entry whose value's overall frequency is **< 1%** of total rows is
flagged. This is what catches `North Korea` (0.1% of rows) even though every other field
on those rows looks normal — see `02-dataset.md`.
Sub-score: `100 * (1 - frequency / 0.01)`, clamped to [40, 100] when it fires at all
(rarity is a strong, not a weak, signal here given how uniform the rest of the data is).

### R4 — Session anomaly (`SESSION_ANOMALY`)
Two sub-checks per `Session_ID`:
- **Spans multiple IPs**: if a session ID appears with more than one distinct
  `IP_Address`, hard-flag (score 90) with reason "session used from N different source
  IPs" — a classic hijack/shared-credential signal.
- **High volume**: if a session's total request count is ≥ the dataset's 99th percentile
  session count (compute at ingestion time), flag with sub-score
  `min(100, (count / p99) * 60)`.

## Combining rules into a final decision

1. Run all applicable rules for a `LogEntry`; collect `(reasonCode, subScore)` pairs.
2. `anomaly_score = min(100, max(subScores) + 0.25 * sum(other subScores))` — the
   strongest signal dominates, but corroborating weaker signals push the score up
   further (an entry that's both rare-location AND part of a rate burst is worse than
   either alone).
3. **Flag** if `anomaly_score >= FLAG_THRESHOLD` (default **50**), OR if any hard-flag
   rule fired (currently just the multi-IP session case).
4. Persist one `Anomaly` row per flagged `LogEntry` with all `reasonCodes` that fired,
   the final `score`, and a **deterministically generated** `reasonSummary` (plain
   string built from a template per reason code + the actual numbers, e.g. *"IP
   15.6.62.53 sent 49 requests in a 10-minute window (threshold: 8)."*). This summary is
   backend-generated, not AI-generated — the AI step (see `06`) takes this structured
   reasoning as input and expands it into a friendlier explanation + root cause + next
   step.

## Config

All thresholds live in `backend/src/config/rules.config.ts` as named constants (not
magic numbers inline), so they're one place to tune and one place to reference in the
README's "approach" section:

```ts
export const RULES_CONFIG = {
  RATE_BURST_WINDOW_MIN: 10,
  RATE_BURST_THRESHOLD: 8,
  ERROR_BURST_WINDOW_MIN: 10,
  ERROR_BURST_MIN_SAMPLE: 3,
  ERROR_BURST_FRACTION: 0.6,
  RARITY_THRESHOLD: 0.01,
  SESSION_VOLUME_PERCENTILE: 0.99,
  FLAG_THRESHOLD: 50,
};
```

## Testing expectation (Backend Agent, Phase B3)

Write unit tests that assert, against the real `Resources/log-data.csv`:
- The `15.6.62.53` IP is flagged with `RATE_BURST` in its reason codes.
- At least the majority of the 10 `North Korea` rows are flagged with `RARE_LOCATION`.
- A synthetic empty dataset and a synthetic malformed row (missing timestamp) are
  rejected per `04-api-contract.md`'s `422`/rejection behavior, not silently dropped.
