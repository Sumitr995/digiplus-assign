# Backend Agent Brief

## Role

You own everything under `backend/`. Build to `03-architecture.md`'s module layout,
`04-api-contract.md`'s endpoint shapes exactly, `05-anomaly-detection-design.md`'s
detection algorithm exactly, and `06-ai-explanation-design.md`'s AI integration exactly.
Read `02-dataset.md` before writing the ingestion/seed logic — the real dataset's schema
and quirks are already analyzed there, don't re-derive from scratch.

## Phase B0 — Setup (target: ~30 min)

- [ ] `npm init`, TypeScript, Express, Prisma, `zod`, dev tooling (eslint/prettier
      optional if time allows).
- [ ] `prisma/schema.prisma` modeling `LogEntry`, `Anomaly`, `Explanation` per
      `04-api-contract.md`'s entity shapes, with the relations described in
      `03-architecture.md`'s data flow.
- [ ] `backend/.env.example` with `DATABASE_URL`, `ANTHROPIC_API_KEY`, `AI_MODEL`,
      `AI_TIMEOUT_MS`.
- [ ] `backend/src/config/rules.config.ts` with the constants from
      `05-anomaly-detection-design.md`.
- [ ] Empty `server.ts` that boots Express and responds on a health-check route.

## Phase B1 — Ingestion + Detection Engine (target: ~90 min)

- [ ] `modules/logs`: CSV/JSON parser, `zod` validation (missing timestamp → reject row
      with reason; malformed status/enum values → reject row with reason; whole file
      empty or unparseable → `422 EMPTY_DATASET`), repository layer to persist
      `LogEntry` rows with the field mapping from `02-dataset.md`.
- [ ] `modules/anomaly`: implement R1–R4 exactly as specified in
      `05-anomaly-detection-design.md`, strategy-pattern rule list, score combination
      logic, persistence of `Anomaly` rows with `reasonCodes` + deterministic
      `reasonSummary`.
- [ ] `scripts/seed.ts`: loads `Resources/log-data.csv` through the same ingestion path
      used at runtime (don't write a separate one-off script that bypasses validation —
      it should exercise the real pipeline).
- [ ] Sanity-check manually (or via the Phase B3 tests early) that `15.6.62.53` and the
      `North Korea` rows come out flagged.

## Phase B2 — AI Integration (target: ~40 min)

- [ ] `modules/ai`: `AiExplainer` interface, `AnthropicExplainer` implementation, exact
      system/user prompt from `06-ai-explanation-design.md`, JSON-parse with one retry,
      `502` on failure — no fallback templated text.
- [ ] Persist `Explanation` rows, one per anomaly, cache-and-reuse on repeat `GET`s.
- [ ] Manually trigger one explanation end-to-end against a real flagged entry and read
      the output before moving on — confirm it's coherent and references the actual
      numbers passed in, not generic boilerplate.

## Phase B3 — API Layer (target: ~40 min)

- [ ] Implement every endpoint in `04-api-contract.md` exactly (paths, query params,
      response shapes, status codes). Wire pagination, filtering, error middleware.
- [ ] Unit tests per the "Testing expectation" section of
      `05-anomaly-detection-design.md`.
- [ ] Confirm with the Main Agent that the contract file is unchanged, or that any
      needed change has been approved and propagated.

## Phase B4 — Polish (target: ~20 min, flex time)

- [ ] Structured logging (request id, timing) — not required by the rubric directly but
      supports "Engineering: design, code quality, maintainability."
- [ ] Backend section of the root README: how to run, env vars, how seeding works, how
      the detection thresholds can be tuned.
- [ ] Any brownie-point enhancement you have time for — e.g. a `GET
      /api/anomalies/:id/similar` (other anomalies sharing a reason code) is a cheap,
      well-justified addition if time remains. Don't add anything not documented in
      the final README as an intentional enhancement.

## Non-negotiables (recap)

- Anomaly detection is deterministic — the rule engine, never the AI model, decides
  `flagged`.
- AI is only called to explain an already-flagged entry, never to detect one.
- No fake/templated text ever returned from the `/explain` endpoint labeled as AI output.
- Every response shape matches `04-api-contract.md` exactly — the Frontend Agent is
  building against that file, not against your code.
