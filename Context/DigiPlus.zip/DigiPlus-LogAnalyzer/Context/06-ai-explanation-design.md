# AI Explanation Design (Backend Agent implements this exactly)

## Scope

The AI is used **only** to turn an already-flagged `Anomaly` (deterministically produced
per `05-anomaly-detection-design.md`) into three human-facing strings: `explanation`,
`likelyRootCause`, `recommendedNextStep`. The AI never sees raw, unflagged logs and is
never asked to judge anomalousness — it receives the rule engine's own reasoning as
input, which keeps it grounded and auditable instead of hallucinating causes.

## Provider adapter

```ts
interface AiExplainer {
  explain(input: ExplainInput): Promise<ExplainOutput>;
}

interface ExplainInput {
  logEntry: LogEntry;
  reasonCodes: string[];
  reasonSummary: string;   // the deterministic summary from the rule engine
  score: number;
  contextStats?: Record<string, number>; // e.g. { ipRequestCountInWindow: 49, threshold: 8 }
}

interface ExplainOutput {
  explanation: string;
  likelyRootCause: string;
  recommendedNextStep: string;
}
```

One implementation: `AnthropicExplainer` (Claude API). A `MockExplainer` (deterministic
canned output, clearly named as a **test double**, never wired into the real app paths)
exists only under `backend/tests/` for unit-testing the surrounding service without
network calls — this is not the same thing as the "no templated AI output" rule, which
is about the *production* explanation endpoint always calling a real model.

## Prompt design

**System prompt:**
```
You are a site-reliability assistant. You are given a log entry that a deterministic
anomaly-detection system has ALREADY flagged, along with the exact rule(s) that fired
and the numbers behind them. Do not question or re-evaluate whether it's anomalous —
that decision is final and made by other software. Your only job is to explain it
clearly to a human operator and suggest what they should check next.

Respond ONLY with a JSON object matching this shape, no prose outside the JSON:
{
  "explanation": "1-3 plain-English sentences describing what happened, in a way a
    non-expert on-call engineer could understand",
  "likelyRootCause": "1-2 sentences on the most plausible cause given the evidence",
  "recommendedNextStep": "1-2 concrete, actionable next steps"
}
```

**User message** (templated from `ExplainInput`):
```
Flagged log entry:
- timestamp: {logEntry.timestamp}
- source IP: {logEntry.source}
- event type: {logEntry.eventType}
- status code: {logEntry.statusCode}
- severity: {logEntry.severity}
- location: {logEntry.location}
- session: {logEntry.sessionId}

Detection reasoning (already decided, do not re-evaluate):
- rule(s) fired: {reasonCodes.join(", ")}
- summary: {reasonSummary}
- score: {score}/100
- supporting numbers: {JSON.stringify(contextStats)}
```

## Reliability handling

- Parse the model response as JSON; if parsing fails, retry once with a stricter
  reminder appended. If it still fails, return a `502 AI_PROVIDER_ERROR` per
  `04-api-contract.md` — **never** substitute templated text pretending to be the AI's
  output.
- Timeout the API call (e.g. 15s) and surface the same `502` on timeout.
- Cache the `Explanation` row once generated; `GET /api/anomalies/:id` returns it without
  re-calling the model. `POST /api/anomalies/:id/explain { force: true }` is the only way
  to regenerate.

## Config

```
ANTHROPIC_API_KEY=...
AI_MODEL=claude-sonnet-4-6   # confirm current recommended model name at build time
AI_TIMEOUT_MS=15000
```

Document all three in `backend/.env.example` and in the README's "AI config" section
(required by the submission checklist in `01-problem-statement.md`).
