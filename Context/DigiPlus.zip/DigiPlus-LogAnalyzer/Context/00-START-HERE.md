# Context Folder — Orientation

This folder is the single shared brain for every agent working on the **Smart Log
Analyzer & Anomaly Detector** assessment (DigiPlus ACOE technical assessment, 3.5-hour
build). It exists so that a Main Agent, a Backend Agent, and a Frontend Agent — possibly
different chat sessions, models, or tools — stay in sync without you re-explaining the
project every time.

## Reading order

| # | File | Who reads it |
|---|------|---------------|
| 00 | `START-HERE.md` (this file) | Everyone, first |
| 01 | `01-problem-statement.md` | Everyone |
| 02 | `02-dataset.md` | Everyone (backend especially) |
| 03 | `03-architecture.md` | Everyone |
| 04 | `04-api-contract.md` | Everyone — this is the contract, treat as law |
| 05 | `05-anomaly-detection-design.md` | Backend Agent, Main Agent |
| 06 | `06-ai-explanation-design.md` | Backend Agent, Main Agent |
| 07 | `07-main-agent.md` | Main Agent |
| 08 | `08-backend-agent.md` | Backend Agent |
| 09 | `09-frontend-agent.md` | Frontend Agent |
| 10 | `10-acceptance-criteria.md` | Everyone, especially Main Agent at sign-off |
| — | `PROGRESS.md` | Main Agent maintains; others read to check status |

## Ground rules for every agent

1. **`04-api-contract.md` is the only truth about HTTP shapes.** If you need to deviate,
   stop and propose an edit to that file — don't quietly build something different on
   your side of the fence.
2. **The anomaly-detection logic is deterministic and hand-written** (see `05`). The AI
   model is never asked "is this anomalous?" — only "explain why this already-flagged
   entry was flagged." This is a hard requirement from the problem statement, not a
   style preference.
3. **Stay inside your lane.** Backend Agent owns everything under `/backend`. Frontend
   Agent owns everything under `/frontend`. Main Agent owns root-level scaffolding,
   `Context/PROGRESS.md`, integration checks, and the final `README.md`.
4. **Work in the phases defined in your own brief file (`08` or `09`).** Don't jump ahead
   to polish before the current phase's core functionality works end-to-end.
5. **Real dataset lives in `../Resources/log-data.csv`** (10,000 rows). Use it — don't
   invent a different schema than what's actually in that file. `02-dataset.md` already
   analyzed it for you.
6. When in doubt, the original PDF problem statement is condensed faithfully in
   `01-problem-statement.md` — nothing here should contradict it. If something here ever
   seems to, the original problem statement wins.
