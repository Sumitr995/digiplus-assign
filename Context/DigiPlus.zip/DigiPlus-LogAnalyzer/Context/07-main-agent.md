# Main Agent Brief (Orchestrator)

## Role

You coordinate the Backend Agent and Frontend Agent. You do not write feature logic
yourself. You own:

- Root-level repo scaffolding (folder structure from `03-architecture.md`, root
  `docker-compose.yml`, root `.gitignore`, root `README.md` skeleton).
- `Context/04-api-contract.md` as the single source of truth — you're the one who
  approves any change to it.
- `Context/PROGRESS.md` — update it after every phase, for every agent.
- Integration checks between phases (does the frontend's typed client actually match
  what the backend implemented; does a full `docker-compose up` work end to end).
- Final sign-off against `10-acceptance-criteria.md` and assembling the final
  `README.md`.

## Dispatch

Give the Backend Agent: `08-backend-agent.md`, `02-dataset.md`, `04-api-contract.md`,
`05-anomaly-detection-design.md`, `06-ai-explanation-design.md`.

Give the Frontend Agent: `09-frontend-agent.md`, `04-api-contract.md`.

Both agents should also have read `00-START-HERE.md`, `01-problem-statement.md`, and
`03-architecture.md` first.

## Phase alignment (run in parallel where marked)

| Backend phase | Frontend phase | Can run in parallel? | Main Agent gate before next row |
|---|---|---|---|
| B0 Setup | F0 Setup (uses mock data) | ✅ yes | Both scaffolds build/run; contract file unchanged from what both read |
| B1 Core ingestion + detection | F1 Core list/timeline view (mocked) | ✅ yes | Backend detection tested against real dataset per `05`'s testing section |
| B2 AI integration | F2 Detail view (mocked AI response) | ✅ yes | Backend `/explain` endpoint returns real model output at least once |
| B3 API layer finalized | F3 Integration — swap mocks for real API | ❌ frontend needs backend's live API here | Full round trip works: ingest → list → detail → explain, in the running app |
| B4 Polish, tests, backend README section | F4 Polish, enhancements, frontend README section | ✅ yes | Run through `10-acceptance-criteria.md` line by line |

## Integration checks to run after B3/F3

1. `docker-compose up` from a clean checkout succeeds.
2. Seed the real `Resources/log-data.csv`, confirm ingestion response matches the shape
   in `04-api-contract.md`.
3. Confirm the `15.6.62.53` burst and at least some `North Korea` rows show up flagged
   in the UI (ground-truth spot check from `02-dataset.md`).
4. Open a flagged entry's detail view, trigger explanation generation, confirm it's a
   real model response (not identical boilerplate across different entries — if two
   different anomalies get suspiciously identical explanation text, that's a red flag
   worth investigating before sign-off).
5. Test an empty-dataset ingest and a malformed-row ingest; confirm graceful handling
   per `04-api-contract.md`, not a crash.

## PROGRESS.md maintenance

After each phase completes, update the status table, log any decisions that deviated
from the Context docs (and why), and log any open blockers. See `PROGRESS.md` in this
folder for the template — keep it current, it's the shared status view across agents/
sessions.

## Final sign-off

Before declaring the assessment ready to submit:
- [ ] Every checkbox in `10-acceptance-criteria.md` is checked or explicitly noted as an
      accepted limitation.
- [ ] Root `README.md` contains: setup instructions, AI config instructions, approach
      summary (link back to `05` and `06`'s design), assumptions (from `02`), and known
      limitations (e.g. SQLite-for-dev trade-off from `03`).
- [ ] A clean `git clone` + documented setup steps actually produces a running app.
