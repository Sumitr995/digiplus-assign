# Acceptance Criteria (mapped to the assessment rubric)

Main Agent checks every box below before sign-off. Each item traces back to one rubric
row from `01-problem-statement.md`.

## Functionality
- [ ] `docker-compose up` from a clean checkout runs the full app.
- [ ] Real `Resources/log-data.csv` (10,000 rows) ingests without crashing.
- [ ] List view, detail view, and flagged-entry highlighting all work end-to-end.
- [ ] Empty dataset and malformed rows are handled gracefully (per `04-api-contract.md`),
      not with a server crash or a blank white-screen frontend.

## AI
- [ ] `/explain` calls a real model — verified by comparing explanation text across at
      least two different anomalies and confirming they're substantively different and
      reference the actual numbers/fields of each entry.
- [ ] AI is never the thing deciding `flagged` — confirmed by reading
      `modules/anomaly/*` and confirming no AI/model call exists in that path.
- [ ] A forced AI failure (bad API key, or unplug network) produces the documented `502`
      and a clear frontend error state — not fabricated text.

## Engineering
- [ ] Backend follows the module boundaries in `03-architecture.md` (logs / anomaly / ai
      / stats / api as separate modules, not one giant file).
- [ ] Anomaly rules are implemented as independent, addable units (strategy pattern),
      not one monolithic if/else block.
- [ ] Config/thresholds live in `rules.config.ts`, not hardcoded inline.
- [ ] TypeScript types shared conceptually between `04-api-contract.md` and both codebases
      (no drift between what backend returns and what frontend expects).

## Data
- [ ] `LogEntry`, `Anomaly`, `Explanation` are all actually persisted (survive a server
      restart), not held in memory.
- [ ] Pagination works correctly at full scale (10,000 rows / ~400 pages at default page
      size).
- [ ] Derived fields (`severity`) are computed consistently and documented in the README.

## UX
- [ ] Flagged entries are visually obvious in the list/timeline (not just a text label
      buried in a table cell).
- [ ] Loading and error states exist for every async action, especially AI explanation
      generation (which is the slowest call in the app).
- [ ] Filtering (flagged-only, severity, date range) actually works against the real
      dataset.

## Problem solving
- [ ] README's "approach" and "assumptions" sections clearly state: why these four
      anomaly rules, why SQLite-for-dev, why on-demand (not eager) AI explanation
      generation, and what the derived-severity mapping is.
- [ ] At least one ground-truth check passes: the `15.6.62.53` burst IP and the
      `North Korea` rarity rows are actually flagged by the running system (see
      `02-dataset.md`).
- [ ] Known limitations are stated honestly in the README, not glossed over (e.g. rule
      thresholds are hand-picked/heuristic, not statistically fit; SQLite isn't
      production-grade concurrency; no auth/multi-tenancy).
