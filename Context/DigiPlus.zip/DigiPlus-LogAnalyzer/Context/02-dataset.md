# Dataset

Source file: `Resources/log-data.csv` — this is the real dataset the app must be built
and demoed against (not the PDF's illustrative table).

## Raw schema

| Column | Type | Notes |
|---|---|---|
| `Timestamp` | string, `YYYY-MM-DD HH:MM:SS` | 1-minute cadence, spans 2023-01-01 00:00:00 → 2023-01-07 22:39:00 (~7 days) |
| `IP_Address` | string | source IP, almost all unique |
| `Request_Type` | enum | `GET`, `PUT`, `POST`, `DELETE` — near-uniform distribution (~2,500 each) |
| `Status_Code` | enum | `200`, `301`, `403`, `404`, `500` — near-uniform distribution (~2,000 each) |
| `User_Agent` | enum | `Chrome`, `Firefox`, `Safari`, `Edge`, `Opera`, `Bot` — near-uniform (~1,650 each) |
| `Session_ID` | string (numeric) | 3,663 unique values across 10,000 rows → sessions repeat |
| `Location` | enum | `Germany`, `Brazil`, `India`, `USA`, `France`, `Canada`, `China` (~1,400 each) **and `North Korea`, only 10 rows** |

10,000 rows total. No column is literally named "severity" or "event type" — both are
derived (see Field Mapping below). This is a deliberate schema decision to document in
the README's "assumptions" section.

## Field mapping (raw CSV → app's persisted LogEntry)

| App field (from problem statement) | Source |
|---|---|
| `timestamp` | `Timestamp` |
| `source` | `IP_Address` |
| `eventType` | `Request_Type` (+ implicit path/action semantics) |
| `severity` | **derived** from `Status_Code`: `500→critical`, `403/404→medium`, `301→low`, `200→info` |
| extra context fields kept | `user_agent`, `session_id`, `location` |

## What's actually in the data (from direct analysis — use this, don't re-derive from
scratch)

- **Rate distribution is otherwise uniform** across request type, status code, and user
  agent — there's no dominant "normal" pattern to lean on beyond frequency counts, which
  is exactly why rarity- and rate-based rules (not just "status 500 = bad") are needed.
- **`North Korea` is a clear injected rarity anomaly**: 10 rows out of 10,000 (0.1%),
  vs. ~1,400 for every other location. Each of those 10 rows is otherwise a normal-looking
  row (varied status codes, varied user agents) — the anomaly signal is purely
  *geographic rarity*, which a naive "flag on 5xx only" detector would completely miss.
- **One IP (`15.6.62.53`) appears 49 times**, while the dataset's ~9,952 other IPs are
  essentially all singletons. This is a textbook burst/rate anomaly (a single source
  hammering the system) that a per-IP request-rate rule should catch immediately.
- **Session IDs repeat unevenly**: most sessions appear 1–3 times, but the busiest
  sessions (`3313`, `4501`, `2063`, …) reach 9–11 occurrences — useful signal for a
  session-activity rule, and worth checking whether a busy session ever spans more than
  one IP (a hijack/shared-credential signal).
- Data is otherwise clean: no missing values observed in a full scan, consistent
  timestamp format, consistent column count. The app must still defensively validate for
  missing timestamps / malformed rows / empty file, per the problem statement, since real
  submissions or future uploads won't be guaranteed this clean.

## Assumptions to state explicitly in the README

1. "Severity" is a derived field, not a raw column — the mapping above is the app's own
   design decision.
2. "Event type" is read directly from `Request_Type`; there's no richer action/path field
   in this dataset (unlike the PDF's illustrative `GET /api/users` style messages), so the
   detail view should not fabricate a fake request path.
3. The optional GitHub reference dataset mentioned in the PDF
   (`github.com/Anchit-Nayak/Assignment-Data`) was not required since a full, real
   10,000-row dataset was already provided — noted here so the README can explain why it
   wasn't additionally pulled in.
