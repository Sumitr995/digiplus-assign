# Progress Log

Main Agent updates this after every phase. Other agents read it to know current status
before starting work, especially the F3 "needs live backend" dependency.

## Status table

| Phase | Owner | Status | Notes |
|---|---|---|---|
| B0 Setup | Backend | Not started | |
| B1 Ingestion + Detection | Backend | Not started | |
| B2 AI Integration | Backend | Not started | |
| B3 API Layer | Backend | Not started | |
| B4 Polish | Backend | Not started | |
| F0 Setup | Frontend | Not started | |
| F1 List/Timeline | Frontend | Not started | |
| F2 Detail View | Frontend | Not started | |
| F3 Integration | Frontend | Not started | Blocked on B3 |
| F4 Polish | Frontend | Not started | |

Status values: `Not started` / `In progress` / `Blocked` / `Done`.

## Decisions log

Record anything that deviated from the Context docs, and why.

- (none yet)

## Blockers

- (none yet)

## Ground-truth spot checks (fill in once B1 is done)

- [ ] `15.6.62.53` flagged with `RATE_BURST`? —
- [ ] `North Korea` rows flagged with `RARE_LOCATION`? (how many of the 10) —
- [ ] Any `SESSION_ANOMALY` (multi-IP session) found? —

## Final sign-off

- [ ] `10-acceptance-criteria.md` fully reviewed
- [ ] Root `README.md` assembled
- [ ] Clean-checkout run verified
