# Frontend Agent Brief

## Role

You own everything under `frontend/`. Build against `04-api-contract.md` exactly — treat
it as if the backend is a black box you've never seen the code for. Start with a mock
data layer so you're not blocked waiting on the Backend Agent, then swap to the real API
in Phase F3.

## Phase F0 — Setup (target: ~25 min)

- [ ] Vite + React + TypeScript + Tailwind scaffold.
- [ ] `src/api/`: one typed function per endpoint in `04-api-contract.md`, all typed
      against the `LogEntry` / `Anomaly` / `Explanation` interfaces defined there. Add a
      `src/api/mock.ts` that returns realistic fake data matching those same shapes (base
      it loosely on the real field values described in `02-dataset.md` — real-looking
      IPs, locations including a rare one, etc.) so early UI work isn't blocked.
- [ ] TanStack Query provider set up.
- [ ] Routing: a list route and a detail route at minimum.

## Phase F1 — List/Timeline View (target: ~50 min, against mocks)

- [ ] Paginated table or timeline of `LogEntry` rows. **Flagged entries visibly
      highlighted** (color/badge/icon — this is an explicit requirement, not optional
      styling).
- [ ] Filters matching the query params in `04-api-contract.md`'s `GET /api/logs`:
      flagged-only toggle, severity filter, date range.
- [ ] Empty-state UI (no logs ingested yet) and loading-state UI.
- [ ] Clicking a row navigates to its detail view.

## Phase F2 — Detail View (target: ~40 min, against mocks)

- [ ] Full `LogEntry` fields displayed clearly.
- [ ] If flagged: show the `Anomaly`'s `reasonCodes` + `reasonSummary` + `score`
      prominently.
- [ ] AI explanation panel: shows `explanation` / `likelyRootCause` /
      `recommendedNextStep` once available. Before generated: a clear "Generate
      explanation" call-to-action (calls `POST /api/anomalies/:id/explain`). While
      loading: a loading state (this call can take a few seconds — don't let the UI look
      frozen or broken). On `502`/failure: a clear error state with a retry button — never
      silently show blank or fake text.

## Phase F3 — Integration (target: ~35 min)

- [ ] Swap `src/api/mock.ts` usage for the real backend calls once Backend Phase B3 is
      done (coordinate via `Context/PROGRESS.md`).
- [ ] Handle real pagination (400 pages at default page size for the full 10,000-row
      dataset — make sure the pager UI actually works at that scale, don't just test with
      3 rows).
- [ ] Handle the real error shapes from `04-api-contract.md` (`400`/`404`/`422`/`502`)
      with appropriate UI, not just `console.error`.
- [ ] Confirm an ingest → list → detail → explain round trip actually works against the
      live backend, using the real `Resources/log-data.csv`.

## Phase F4 — Polish (target: ~20 min, flex time)

- [ ] Responsive layout pass (doesn't need to be pixel-perfect, needs to not break on a
      laptop-width screen).
- [ ] Basic accessibility: semantic elements, focus states, alt text where relevant.
- [ ] Frontend section of the root README: how to run, any env vars (API base URL).
- [ ] Optional, well-justified enhancement if time remains — e.g. a small
      `GET /api/stats/summary`-backed header showing total logs / total flagged /
      breakdown by reason code (cheap, high UX payoff, and the endpoint already exists in
      the contract for exactly this purpose).

## Non-negotiables (recap)

- Flagged entries must be visually distinguishable in the list/timeline view — this is
  an explicit basic requirement, not a nice-to-have.
- Never fabricate AI explanation text client-side if the API call fails — show a real
  error/retry state instead.
- Build against `04-api-contract.md`'s shapes, not whatever the backend happens to return
  during development — if there's a mismatch, that's a contract violation to flag to the
  Main Agent, not something to silently work around with ad-hoc field renaming.
